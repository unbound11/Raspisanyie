package by.km.raspisanie;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/** Хранилище: расписание (JSON) и настройки лежат в одном месте для приложения и виджета. */
final class Store {
    static final String PREFS = "km";
    static final String KEY_SCHED = "sched";

    static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static String defaultJson(Context c) {
        try {
            InputStream in = c.getAssets().open("schedule.json");
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            in.close();
            return bo.toString("UTF-8");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    static String loadJson(Context c) {
        String s = prefs(c).getString(KEY_SCHED, null);
        return (s == null || s.isEmpty()) ? defaultJson(c) : s;
    }

    static boolean saveJson(Context c, String json) {
        try {
            Sched.parse(json);
        } catch (Exception e) {
            return false;
        }
        prefs(c).edit().putString(KEY_SCHED, json).apply();
        return true;
    }

    static void reset(Context c) {
        prefs(c).edit().remove(KEY_SCHED).apply();
    }

    static Sched load(Context c) {
        try {
            return Sched.parse(loadJson(c));
        } catch (Exception e) {
            try {
                return Sched.parse(defaultJson(c));
            } catch (Exception e2) {
                throw new RuntimeException(e2);
            }
        }
    }
}
