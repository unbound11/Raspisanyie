package by.km.raspisanie;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView web;
    private String pendingOpen = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient());
        setContentView(web);
        readIntent(getIntent());
        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl("file:///android_asset/index.html");
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        readIntent(intent);
        web.evaluateJavascript("window.kmOpen&&window.kmOpen()", null);
    }

    private synchronized void readIntent(Intent i) {
        if (i != null && i.hasExtra("di")) {
            pendingOpen = i.getIntExtra("di", 0) + "," + i.getIntExtra("w", 1);
            i.removeExtra("di");
            i.removeExtra("w");
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    public void onBackPressed() {
        // Сначала даём странице закрыть окно редактирования, если оно открыто.
        web.evaluateJavascript("(window.kmBack&&window.kmBack())?1:0", value -> {
            if (!"1".equals(value)) {
                if (web.canGoBack()) web.goBack(); else finish();
            }
        });
    }

    /** Мост между страницей (JS) и Android: расписание и настройки общие с виджетом. */
    private class Bridge {
        @JavascriptInterface
        public String getSchedule() {
            return Store.loadJson(MainActivity.this);
        }

        @JavascriptInterface
        public boolean saveSchedule(String json) {
            boolean ok = Store.saveJson(MainActivity.this, json);
            if (ok) ScheduleWidget.refreshAll(MainActivity.this);
            return ok;
        }

        @JavascriptInterface
        public String resetSchedule() {
            Store.reset(MainActivity.this);
            ScheduleWidget.refreshAll(MainActivity.this);
            return Store.loadJson(MainActivity.this);
        }

        @JavascriptInterface
        public int getSub() {
            return Store.prefs(MainActivity.this).getInt("sub", 1);
        }

        @JavascriptInterface
        public void setSub(int v) {
            Store.prefs(MainActivity.this).edit().putInt("sub", v == 2 ? 2 : 1).apply();
            ScheduleWidget.refreshAll(MainActivity.this);
        }

        @JavascriptInterface
        public boolean getFlip() {
            return Store.prefs(MainActivity.this).getBoolean("flip", false);
        }

        @JavascriptInterface
        public void setFlip(boolean v) {
            Store.prefs(MainActivity.this).edit().putBoolean("flip", v).apply();
            ScheduleWidget.refreshAll(MainActivity.this);
        }

        @JavascriptInterface
        public boolean getOk() {
            return Store.prefs(MainActivity.this).getBoolean("ok", false);
        }

        @JavascriptInterface
        public void setOk(boolean v) {
            Store.prefs(MainActivity.this).edit().putBoolean("ok", v).apply();
        }

        @JavascriptInterface
        public String takeOpen() {
            synchronized (MainActivity.this) {
                String r = pendingOpen;
                pendingOpen = "";
                return r;
            }
        }
    }
}
