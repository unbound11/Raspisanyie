package by.km.raspisanie;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

/** Расписание: разбор JSON, выбор пар на день, лента "пара / перерыв / пара". */
final class Sched {

    static final class Lesson {
        int s, w, g;          // слот, неделя (0 = обе), подгруппа (0 = вся группа)
        String t, k, r, p;    // тип, ключ предмета, аудитория, преподаватель
    }

    static final class Subj {
        String n, sh;         // полное и короткое название
    }

    /** Один "лист" ленты дня: либо пара, либо перерыв между парами. */
    static final class Item {
        static final int LESSON = 0, BREAK = 1;
        int type;
        Lesson les;           // для пары
        Lesson next;          // для перерыва: какая пара следует за ним
        int from, to;         // минуты от полуночи
    }

    int[] startMin, endMin;
    String[] startTxt, endTxt;
    final Map<String, Subj> subj = new HashMap<>();
    final List<List<Lesson>> days = new ArrayList<>();
    long anchor;

    static Sched parse(String json) throws JSONException {
        JSONObject o = new JSONObject(json);
        Sched d = new Sched();

        JSONArray sl = o.getJSONArray("slots");
        int n = sl.length();
        if (n == 0) throw new JSONException("no slots");
        d.startMin = new int[n];
        d.endMin = new int[n];
        d.startTxt = new String[n];
        d.endTxt = new String[n];
        for (int i = 0; i < n; i++) {
            JSONObject s = sl.getJSONObject(i);
            String a = s.getString("s"), b = s.getString("e");
            d.startMin[i] = mins(a);
            d.endMin[i] = mins(b);
            d.startTxt[i] = fmt(d.startMin[i]);
            d.endTxt[i] = fmt(d.endMin[i]);
        }

        JSONObject sj = o.getJSONObject("subjects");
        Iterator<String> it = sj.keys();
        while (it.hasNext()) {
            String k = it.next();
            JSONObject so = sj.getJSONObject(k);
            Subj b = new Subj();
            b.n = so.optString("n", k);
            b.sh = so.optString("s", b.n);
            d.subj.put(k, b);
        }

        String[] a = o.optString("anchor", "2026-08-31").split("-");
        d.anchor = utcDay(Integer.parseInt(a[0]), Integer.parseInt(a[1]) - 1, Integer.parseInt(a[2]));

        JSONArray ds = o.getJSONArray("days");
        for (int i = 0; i < 6; i++) {
            List<Lesson> list = new ArrayList<>();
            if (i < ds.length()) {
                JSONArray ls = ds.getJSONObject(i).getJSONArray("l");
                for (int j = 0; j < ls.length(); j++) {
                    JSONObject lo = ls.getJSONObject(j);
                    Lesson l = new Lesson();
                    l.s = lo.getInt("s");
                    if (l.s < 0 || l.s >= n) continue;
                    l.w = lo.optInt("w", 0);
                    l.g = lo.optInt("g", 0);
                    l.t = lo.optString("t", "");
                    l.k = lo.optString("k", "");
                    l.r = lo.optString("r", "");
                    l.p = lo.optString("p", "");
                    list.add(l);
                }
            }
            d.days.add(list);
        }
        return d;
    }

    String shortName(Lesson l) {
        Subj b = subj.get(l.k);
        return b == null ? l.k : b.sh;
    }

    int weekOf(long dayNum, boolean flip) {
        long n = Math.floorDiv(dayNum - anchor, 7L);
        int w = Math.floorMod(n, 2L) == 0 ? 1 : 2;
        return flip ? 3 - w : w;
    }

    List<Lesson> lessonsOn(int di, int w, int sub) {
        List<Lesson> out = new ArrayList<>();
        for (Lesson l : days.get(di)) {
            if ((l.w == 0 || l.w == w) && (l.g == 0 || l.g == sub)) out.add(l);
        }
        out.sort((x, y) -> x.s - y.s);
        return out;
    }

    /** Пары дня и перерывы между ними, по порядку. */
    List<Item> timeline(int di, int w, int sub) {
        List<Lesson> ls = lessonsOn(di, w, sub);
        List<Item> out = new ArrayList<>();
        for (int i = 0; i < ls.size(); i++) {
            Lesson a = ls.get(i);
            Item it = new Item();
            it.type = Item.LESSON;
            it.les = a;
            it.from = startMin[a.s];
            it.to = endMin[a.s];
            out.add(it);
            if (i + 1 < ls.size()) {
                Lesson b = ls.get(i + 1);
                int bf = startMin[b.s];
                if (bf > it.to) {
                    Item br = new Item();
                    br.type = Item.BREAK;
                    br.next = b;
                    br.from = it.to;
                    br.to = bf;
                    out.add(br);
                }
            }
        }
        return out;
    }

    /* ---------- время ---------- */

    static int mins(String t) {
        String[] p = t.trim().split(":");
        return Integer.parseInt(p[0]) * 60 + Integer.parseInt(p[1]);
    }

    static String fmt(int m) {
        return (m / 60 < 10 ? "0" : "") + (m / 60) + ":" + (m % 60 < 10 ? "0" : "") + (m % 60);
    }

    static long utcDay(int y, int m, int d) {
        Calendar u = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        u.clear();
        u.set(y, m, d);
        return u.getTimeInMillis() / 86400000L;
    }

    static long dayNum(Calendar c) {
        return utcDay(c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
    }

    static long today() {
        return dayNum(Calendar.getInstance());
    }

    static int nowMin() {
        Calendar c = Calendar.getInstance();
        return c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE);
    }

    /** День недели: 0 = Пн ... 6 = Вс. 1 января 1970 был четвергом. */
    static int dow(long dayNum) {
        return (int) Math.floorMod(dayNum + 3, 7L);
    }

    /** Локальная дата по номеру дня. */
    static Calendar cal(long dayNum) {
        Calendar u = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        u.setTimeInMillis(dayNum * 86400000L);
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(u.get(Calendar.YEAR), u.get(Calendar.MONTH), u.get(Calendar.DAY_OF_MONTH));
        return c;
    }
}
