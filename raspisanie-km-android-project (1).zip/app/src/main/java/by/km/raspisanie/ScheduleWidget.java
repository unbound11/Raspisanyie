package by.km.raspisanie;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.widget.RemoteViews;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * Виджет 4x2. Стрелки ‹ › листают пары и перерывы, стрелки ▲ ▼ меняют день.
 * Нажатие на дату возвращает "сейчас", нажатие на пару открывает приложение.
 */
public class ScheduleWidget extends AppWidgetProvider {
    static final String ACT_SUB = "by.km.raspisanie.TOGGLE_SUB";
    static final String ACT_FLIP = "by.km.raspisanie.TOGGLE_FLIP";
    static final String ACT_PREV = "by.km.raspisanie.PREV";
    static final String ACT_NEXT = "by.km.raspisanie.NEXT";
    static final String ACT_UP = "by.km.raspisanie.DAY_UP";
    static final String ACT_DOWN = "by.km.raspisanie.DAY_DOWN";
    static final String ACT_RESET = "by.km.raspisanie.RESET";
    static final String ACT_TICK = "by.km.raspisanie.TICK";

    /** Сколько виджет держит ручное положение, потом сам возвращается к "сейчас". */
    static final long MANUAL_MS = 10 * 60 * 1000L;
    static final int PI_FLAGS = PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;

    static final String[] DAY = {"ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"};
    static final String[] MON = {"ЯНВ", "ФЕВ", "МАР", "АПР", "МАЙ", "ИЮН", "ИЮЛ", "АВГ", "СЕН", "ОКТ", "НОЯ", "ДЕК"};

    static final int RED = 0xFFEE2B32, MUTED = 0xFF8D8D89, WHITE = 0xFFF4F4F2, DARK = 0xFF3A3A3A, DONE = 0xFF5A5A5A;

    /** Что сейчас показывает виджет. */
    static final class Pos {
        long day;
        int idx;
        boolean manual;
        List<Sched.Item> items = new ArrayList<>();
    }

    /* ---------- жизненный цикл ---------- */

    @Override
    public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) {
        refreshAll(ctx);
    }

    @Override
    public void onEnabled(Context ctx) {
        refreshAll(ctx);
    }

    @Override
    public void onDisabled(Context ctx) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(tickPi(ctx));
    }

    @Override
    public void onReceive(Context ctx, Intent intent) {
        String a = intent.getAction();
        if (a != null) {
            SharedPreferences p = Store.prefs(ctx);
            boolean mine = true;
            if (ACT_SUB.equals(a)) {
                p.edit().putInt("sub", p.getInt("sub", 1) == 1 ? 2 : 1).apply();
            } else if (ACT_FLIP.equals(a)) {
                p.edit().putBoolean("flip", !p.getBoolean("flip", false)).apply();
            } else if (ACT_RESET.equals(a)) {
                p.edit().remove("wd").remove("wi").remove("wt").apply();
            } else if (ACT_PREV.equals(a) || ACT_NEXT.equals(a) || ACT_UP.equals(a) || ACT_DOWN.equals(a)) {
                navigate(ctx, a);
            } else if (!ACT_TICK.equals(a)) {
                mine = false;
            }
            if (mine) {
                refreshAll(ctx);
                return;
            }
        }
        super.onReceive(ctx, intent);
    }

    /** Обновить все виджеты и поставить будильник на следующее изменение. */
    static void refreshAll(Context ctx) {
        AppWidgetManager mgr = AppWidgetManager.getInstance(ctx);
        int[] ids = mgr.getAppWidgetIds(new ComponentName(ctx, ScheduleWidget.class));
        if (ids == null || ids.length == 0) return;
        mgr.updateAppWidget(ids, build(ctx));
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.setAndAllowWhileIdle(AlarmManager.RTC, nextTickAt(ctx), tickPi(ctx));
    }

    static PendingIntent tickPi(Context ctx) {
        Intent i = new Intent(ctx, ScheduleWidget.class).setAction(ACT_TICK);
        return PendingIntent.getBroadcast(ctx, 9, i, PI_FLAGS);
    }

    static PendingIntent bcast(Context ctx, int code, String action) {
        Intent i = new Intent(ctx, ScheduleWidget.class).setAction(action);
        return PendingIntent.getBroadcast(ctx, code, i, PI_FLAGS);
    }

    /** Ближайший момент, когда картинка может измениться: начало/конец пары, полночь, конец ручного режима. */
    static long nextTickAt(Context ctx) {
        Sched s = Store.load(ctx);
        SharedPreferences p = Store.prefs(ctx);
        Calendar c = Calendar.getInstance();
        long nowMs = c.getTimeInMillis();
        int nowMin = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE);

        Calendar d0 = (Calendar) c.clone();
        d0.set(Calendar.HOUR_OF_DAY, 0);
        d0.set(Calendar.MINUTE, 0);
        d0.set(Calendar.SECOND, 0);
        d0.set(Calendar.MILLISECOND, 0);
        long dayStart = d0.getTimeInMillis();
        Calendar nx = (Calendar) d0.clone();
        nx.add(Calendar.DAY_OF_MONTH, 1);
        long best = nx.getTimeInMillis() + 3000;

        for (int i = 0; i < s.startMin.length; i++) {
            int[] ms = {s.startMin[i], s.endMin[i]};
            for (int m : ms) {
                long t = dayStart + m * 60000L + 3000;
                if (m > nowMin && t > nowMs && t < best) best = t;
            }
        }
        if (p.getLong("wd", 0) != 0) {
            long e = p.getLong("wt", 0) + MANUAL_MS + 3000;
            if (e > nowMs && e < best) best = e;
        }
        // Идёт перерыв: обновляем каждые 2 минуты, чтобы "ещё N мин" не врало.
        Pos pos = resolve(s, p, p.getInt("sub", 1), p.getBoolean("flip", false), Sched.today(), nowMin);
        if (pos.day == Sched.today() && pos.idx < pos.items.size()) {
            Sched.Item it = pos.items.get(pos.idx);
            if (it.type == Sched.Item.BREAK && it.from <= nowMin && nowMin < it.to) {
                long t = nowMs + 120000L;
                if (t < best) best = t;
            }
        }
        return best;
    }

    /* ---------- что показывать ---------- */

    static Pos resolve(Sched s, SharedPreferences p, int sub, boolean flip, long today, int nowMin) {
        long wd = p.getLong("wd", 0);
        long wt = p.getLong("wt", 0);
        boolean manual = wd != 0 && wd >= today && Sched.dow(wd) != 6
                && System.currentTimeMillis() - wt < MANUAL_MS;
        Pos r = new Pos();
        if (manual) {
            r.day = wd;
            r.manual = true;
            r.items = s.timeline(Sched.dow(wd), s.weekOf(wd, flip), sub);
            int n = r.items.size();
            r.idx = n == 0 ? 0 : Math.max(0, Math.min(p.getInt("wi", 0), n - 1));
            return r;
        }
        for (int off = 0; off < 14; off++) {
            long d = today + off;
            if (Sched.dow(d) == 6) continue;
            List<Sched.Item> items = s.timeline(Sched.dow(d), s.weekOf(d, flip), sub);
            if (items.isEmpty()) continue;
            int idx = 0;
            if (off == 0) {
                idx = -1;
                for (int i = 0; i < items.size(); i++) {
                    if (items.get(i).to > nowMin) { idx = i; break; }
                }
                if (idx < 0) continue;   // сегодня всё закончилось, смотрим дальше
            }
            r.day = d;
            r.idx = idx;
            r.items = items;
            return r;
        }
        long d = today;
        if (Sched.dow(d) == 6) d++;
        r.day = d;
        return r;
    }

    static int currentIdx(List<Sched.Item> items, int nowMin) {
        for (int i = 0; i < items.size(); i++) if (items.get(i).to > nowMin) return i;
        return Math.max(0, items.size() - 1);
    }

    static void navigate(Context ctx, String act) {
        navigate(ctx, act, Sched.today(), Sched.nowMin());
    }

    static void navigate(Context ctx, String act, long today, int nowMin) {
        SharedPreferences p = Store.prefs(ctx);
        Sched s = Store.load(ctx);
        int sub = p.getInt("sub", 1);
        boolean flip = p.getBoolean("flip", false);
        Pos cur = resolve(s, p, sub, flip, today, nowMin);
        long day = cur.day;
        int idx = cur.idx;

        if (ACT_NEXT.equals(act)) {
            if (idx + 1 < cur.items.size()) {
                idx++;
            } else {
                for (int k = 1; k <= 14; k++) {
                    long d = day + k;
                    if (Sched.dow(d) == 6) continue;
                    if (!s.timeline(Sched.dow(d), s.weekOf(d, flip), sub).isEmpty()) { day = d; idx = 0; break; }
                }
            }
        } else if (ACT_PREV.equals(act)) {
            if (idx > 0) {
                idx--;
            } else {
                for (int k = 1; k <= 14; k++) {
                    long d = day - k;
                    if (d < today) break;
                    if (Sched.dow(d) == 6) continue;
                    List<Sched.Item> it = s.timeline(Sched.dow(d), s.weekOf(d, flip), sub);
                    if (!it.isEmpty()) { day = d; idx = it.size() - 1; break; }
                }
            }
        } else if (ACT_DOWN.equals(act)) {
            long d = day + 1;
            if (Sched.dow(d) == 6) d++;
            if (d - today <= 60) {
                day = d;
                idx = d == today ? currentIdx(s.timeline(Sched.dow(d), s.weekOf(d, flip), sub), nowMin) : 0;
            }
        } else if (ACT_UP.equals(act)) {
            long d = day - 1;
            if (Sched.dow(d) == 6) d--;
            if (d >= today) {
                day = d;
                idx = d == today ? currentIdx(s.timeline(Sched.dow(d), s.weekOf(d, flip), sub), nowMin) : 0;
            }
        }
        p.edit().putLong("wd", day).putInt("wi", idx).putLong("wt", System.currentTimeMillis()).apply();
    }

    /* ---------- рисование ---------- */

    static RemoteViews build(Context ctx) {
        return build(ctx, Sched.today(), Sched.nowMin());
    }

    static RemoteViews build(Context ctx, long today, int nowMin) {
        Sched s = Store.load(ctx);
        SharedPreferences p = Store.prefs(ctx);
        int sub = p.getInt("sub", 1);
        boolean flip = p.getBoolean("flip", false);
        Pos pos = resolve(s, p, sub, flip, today, nowMin);

        long day = pos.day;
        int di = Sched.dow(day);
        int w = s.weekOf(day, flip);
        long off = day - today;
        boolean isToday = off == 0;
        Calendar dc = Sched.cal(day);

        RemoteViews rv = new RemoteViews(ctx.getPackageName(), R.layout.widget);
        rv.setTextViewText(R.id.tvDay, DAY[di] + " · " + dc.get(Calendar.DAY_OF_MONTH) + " " + MON[dc.get(Calendar.MONTH)]);
        rv.setTextViewText(R.id.tvWeek, w == 1 ? "I" : "II");
        rv.setTextViewText(R.id.tvSub, sub + " ПОДГР");

        Intent open = new Intent(ctx, MainActivity.class);
        open.putExtra("di", di);
        open.putExtra("w", w);
        rv.setOnClickPendingIntent(R.id.root, PendingIntent.getActivity(ctx, 0, open, PI_FLAGS));
        rv.setOnClickPendingIntent(R.id.tvSub, bcast(ctx, 1, ACT_SUB));
        rv.setOnClickPendingIntent(R.id.tvWeek, bcast(ctx, 2, ACT_FLIP));
        rv.setOnClickPendingIntent(R.id.tvDay, bcast(ctx, 15, ACT_RESET));
        rv.setOnClickPendingIntent(R.id.btnPrev, bcast(ctx, 11, ACT_PREV));
        rv.setOnClickPendingIntent(R.id.btnNext, bcast(ctx, 12, ACT_NEXT));
        rv.setOnClickPendingIntent(R.id.btnUp, bcast(ctx, 13, ACT_UP));
        rv.setOnClickPendingIntent(R.id.btnDown, bcast(ctx, 14, ACT_DOWN));

        String tag, time, name, room;
        int tagColor = MUTED, timeColor = WHITE, curSlot = -1;
        boolean dashed = false;

        if (pos.items.isEmpty()) {
            dashed = true;
            tag = "ПАР НЕТ";
            time = "—";
            name = "Свободный день";
            room = "";
            timeColor = MUTED;
        } else {
            Sched.Item it = pos.items.get(pos.idx);
            boolean live = isToday && it.from <= nowMin && nowMin < it.to;
            boolean past = isToday && it.to <= nowMin;
            String when;
            if (isToday) when = live ? "СЕЙЧАС" : (past ? "БЫЛА" : "ДАЛЬШЕ");
            else when = off == 1 ? "ЗАВТРА" : (off == 2 ? "ПОСЛЕЗАВТРА" : "ЧЕРЕЗ " + off + " ДН");

            if (it.type == Sched.Item.LESSON) {
                Sched.Lesson l = it.les;
                curSlot = l.s;
                tag = when;
                tagColor = live ? RED : MUTED;
                time = s.startTxt[l.s];
                timeColor = past ? MUTED : WHITE;
                name = s.shortName(l);
                room = (l.r.isEmpty() ? "—" : l.r) + (l.t.isEmpty() ? "" : " · " + l.t);
            } else {
                dashed = true;
                curSlot = it.next.s;
                int len = it.to - it.from;
                tag = (len >= 30 ? "ОКНО" : "ПЕРЕРЫВ") + " ДО";
                tagColor = live ? RED : MUTED;
                time = Sched.fmt(it.to);
                timeColor = MUTED;
                name = "Дальше: " + s.shortName(it.next);
                String dur = live ? "ещё " + (it.to - nowMin) + " мин" : len + " мин";
                room = dur + (it.next.r.isEmpty() ? "" : " · " + it.next.r);
            }
        }

        rv.setInt(R.id.root, "setBackgroundResource", dashed ? R.drawable.widget_bg_break : R.drawable.widget_bg);
        rv.setTextViewText(R.id.tvTag, tag);
        rv.setTextColor(R.id.tvTag, tagColor);
        rv.setTextViewText(R.id.tvTime, time);
        rv.setTextColor(R.id.tvTime, timeColor);
        rv.setTextViewText(R.id.tvName, name);
        rv.setTextViewText(R.id.tvRoom, room);

        boolean[] has = new boolean[s.startMin.length];
        for (Sched.Item it : pos.items) if (it.type == Sched.Item.LESSON) has[it.les.s] = true;
        SpannableStringBuilder dots = new SpannableStringBuilder();
        for (int i = 0; i < has.length; i++) {
            int color;
            if (i == curSlot) color = RED;
            else if (has[i]) color = (isToday && s.endMin[i] <= nowMin) ? DONE : WHITE;
            else color = DARK;
            int st = dots.length();
            dots.append("●");
            dots.setSpan(new ForegroundColorSpan(color), st, dots.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            if (i < has.length - 1) dots.append(" ");
        }
        rv.setTextViewText(R.id.tvDots, dots);
        return rv;
    }
}
